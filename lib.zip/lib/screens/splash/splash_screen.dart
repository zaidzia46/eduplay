import 'package:eduplay/screens/splash/splash_controller.dart';
import 'package:eduplay/screens/splash/widgets/splash_scene.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SplashScreen extends GetView<SplashController> {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: controller.animation,
        builder: (_, __) {
          return SplashScene(controller: controller);
        },
      ),
    );
  }
}

//
// // views/splash/splash_screen.dart
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../../controller/session_controller.dart';
// import '../../routes/app_routes.dart';
//
// class SplashScreen extends StatefulWidget {
//   const SplashScreen({super.key});
//
//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }
//
// class _SplashScreenState extends State<SplashScreen> {
//   @override
//   void initState() {
//     super.initState();
//     _navigate();
//   }
//
//   Future<void> _navigate() async {
//     await Future.delayed(const Duration(seconds: 2));
//     final session = Get.find<SessionController>();
//
//     if (!session.isParentLoggedIn) {
//       Get.offAllNamed(AppRoutes.login);
//       return;
//     }
//
//     // if (session.activeChild.value != null) {
//     //   Get.offAllNamed(AppRoutes.home);
//     //   return;
//     // }
//
//     Get.offAllNamed(AppRoutes.profileSwitcher);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final size = MediaQuery.of(context).size;
//     final logoWidth = (size.width * 0.72).clamp(220.0, 420.0).toDouble();
//
//     return Scaffold(
//       body: Stack(
//         fit: StackFit.expand,
//         children: [
//           Image.asset('assets/images/splash.png', fit: BoxFit.cover),
//           SafeArea(
//             child: Center(
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 24),
//                 child: Image.asset(
//                   'assets/images/logo.png',
//                   width: logoWidth,
//                   fit: BoxFit.contain,
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

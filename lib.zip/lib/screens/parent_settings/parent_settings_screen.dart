import 'dart:io';

import 'package:eduplay/screens/parent_settings/parent_settings_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../theme/app_colors.dart';
import '../../../theme/app_text_styles.dart';
import '../../../widgets/action_tile.dart';
import '../../widgets/parent_welcome_bg.dart';
import '../auth/auth_controller.dart';

class ParentSettingsView extends StatelessWidget {
  const ParentSettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = Get.find<ParentSettingsController>();
    final session = vm.session;
    const double avatarSize = 84;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Parent Settings',
          style: AppTextStyles.h3.copyWith(color: AppColors.white),
        ),
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          WelcomeBackgroundContainer(
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.29,
              width: double.infinity,
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                SizedBox(height: 90),
                GestureDetector(
                  onTap: vm.setParentAvatar,
                  child: Obx(() {
                    final avatar = vm.profileImagePath.value;
                    return Stack(
                      children: [
                        Container(
                          width: avatarSize,
                          height: avatarSize,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xffFFD84E),
                            border: Border.all(color: Colors.white, width: 4),
                          ),
                          child: CircleAvatar(
                            radius: avatarSize / 2,
                            backgroundColor: AppColors.primaryDark,
                            backgroundImage: avatar != null
                                ? (avatar.startsWith('http://') ||
                                          avatar.startsWith('https://')
                                      ? NetworkImage(avatar)
                                      : FileImage(File(avatar)))
                                : null,
                            child: avatar == null || avatar.isEmpty
                                ? Icon(Icons.person, size: avatarSize * 0.5)
                                : null,
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: const BoxDecoration(
                              color: AppColors.textPrimary,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.camera_alt,
                              size: 14,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    );
                  }),
                ),
                const SizedBox(height: 12),
                Obx(
                  () => Text(
                    session.parentName.value ?? 'Parent',
                    style: AppTextStyles.h3.copyWith(color: AppColors.white),
                  ),
                ),

                const SizedBox(height: 60),

                ActionTile(
                  icon: Icons.lock_outline,
                  label: 'Change Password',
                  subtitle: 'Update your account password',
                  color: AppColors.primary,
                  onTap: () => _showChangePasswordSheet(context, vm),
                ),
                const SizedBox(height: 12),
                ActionTile(
                  icon: Icons.logout_outlined,
                  label: 'Log Out',
                  subtitle: 'Sign out of your parent account',
                  color: AppColors.error,
                  onTap: () => _showLogoutDialog(context, vm),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showChangePasswordSheet(
    BuildContext context,
    ParentSettingsController vm,
  ) {
    Get.bottomSheet(
      Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Change Password', style: AppTextStyles.h4),
                const SizedBox(height: 16),
                TextField(
                  controller: vm.currentPasswordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Current password',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: vm.newPasswordController,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'New password'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: vm.confirmPasswordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Confirm new password',
                  ),
                ),
                const SizedBox(height: 10),
                Obx(
                  () => vm.passwordErrorMessage.isNotEmpty
                      ? Text(
                          vm.passwordErrorMessage.value,
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.error,
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
                const SizedBox(height: 12),
                Obx(
                  () => ElevatedButton(
                    onPressed: vm.isChangingPassword.value
                        ? null
                        : vm.changePassword,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 48),
                    ),
                    child: vm.isChangingPassword.value
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Text('Update Password'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, ParentSettingsController vm) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Log Out?', style: AppTextStyles.h3),
        content: Text(
          'You\'ll need to sign in again to access EduPlay.',
          style: AppTextStyles.bodySecondary,
        ),
        actions: [
          ElevatedButton(
            onPressed: () async {
              Get.back();
              await vm.logout();
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            child: const Text('Log Out'),
          ),
        ],
      ),
    );
  }
}
